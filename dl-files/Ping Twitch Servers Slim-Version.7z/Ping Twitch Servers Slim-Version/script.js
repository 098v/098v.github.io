function cb(self, delta) {
	$(self).find('td:last-child').text(delta + ' ms');
	if ($(self).find('td:first-child').text() === $('tbody tr:last-child td:first-child').text()) {
		$('table').tablesorter();
	} else {
		ping('http://' + $(self).next().find('td:first-child').text() + ':1935').then(function(delta) {
			cb($(self).next(), delta);
		});
	}
}
$('.ping').click(function() {
	var self = $('tbody tr:first-child');
	ping('http://' + $(self).find('td:first-child').text() + ':1935').then(function(delta) {
		cb(self, delta);
	});
});